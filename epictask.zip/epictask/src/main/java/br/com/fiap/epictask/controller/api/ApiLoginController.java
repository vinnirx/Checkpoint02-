package br.com.fiap.epictask.controller.api;

import java.net.URI;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import br.com.fiap.epictask.model.Login;
import br.com.fiap.epictask.repository.LoginRepository;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/login")
@Slf4j
public class ApiLoginController {

	@Autowired
	private LoginRepository loginRepository;

	@GetMapping
	@Cacheable("logins")
	public Page<Login> index(
			@RequestParam(required = false) String name,
			@PageableDefault(size = 20) Pageable pageable
			) {
		
		if (name == null)
			return loginRepository.findAll(pageable);
		
		//TODO usar contains
		return loginRepository.findByNameLike("%" + name + "%", pageable);
	}

	@PostMapping
	@CacheEvict(value = "logins", allEntries = true)
	public ResponseEntity<Login> create(@RequestBody @Valid Login login, UriComponentsBuilder uriBuilder) {
		loginRepository.save(login);
		URI uri = uriBuilder.path("/api/login/{id}").buildAndExpand(login.getId()).toUri();
		return ResponseEntity.created(uri).body(login);
	}

	@GetMapping("{id}")
	public ResponseEntity<Login> get(@PathVariable Long id) {
		return ResponseEntity.of(loginRepository.findById(id));
	}

	@DeleteMapping("{id}")
	@CacheEvict(value = "logins", allEntries = true)
	public ResponseEntity<Login> delete(@PathVariable Long id) {
		Optional<Login> task = loginRepository.findById(id);

		if (task.isEmpty())
			return ResponseEntity.notFound().build();

		loginRepository.deleteById(id);

		return ResponseEntity.ok().build();

	}

	@PutMapping("{id}")
	@CacheEvict(value = "logins", allEntries = true)
	public ResponseEntity<Login> update(@RequestBody @Valid Login newLogin, @PathVariable Long id) {
		Optional<Login> optional = loginRepository.findById(id);

		if (optional.isEmpty())
			return ResponseEntity.notFound().build();

		Login login = optional.get();

		login.setName(newLogin.getName());
		login.setEmail(newLogin.getEmail());
		login.setPassword(newLogin.getPassword());

		loginRepository.save(login);

		log.info("Tarefa id=" + id + " alterada para " + login.toString());

		return ResponseEntity.ok(login);

	}
}
